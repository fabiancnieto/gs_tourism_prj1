<?php

/*
 * DB Classes
 */
include ("db/DbConn.php");
/*
 * LOGIC Classes
 */
include ("logic/About.php");
include ("logic/Plans.php");
include ("logic/Itinerary.php");
include ("logic/Pricing.php");
include ("logic/Photos.php");
include ("logic/Conditions.php");
include ("logic/News.php");
include ("logic/CarFleet.php");

?>
